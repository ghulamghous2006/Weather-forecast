import requests
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
import numpy as np
import tkinter as tk
from tkinter import simpledialog

sns.set(style="whitegrid")

# OpenWeatherMap API Key and endpoint
API_KEY = "e941583daf870839c5228a3f4a5f0ae4"
ONE_CALL_ENDPOINT = "https://api.openweathermap.org/data/2.5/onecall"
CURRENT_WEATHER_ENDPOINT = "https://api.openweathermap.org/data/2.5/weather"

# City coordinates
city_coords = {
    "Delhi": (28.6139, 77.2090),
    "Mumbai": (19.0760, 72.8777),
    "Chennai": (13.0827, 80.2707)
}

# Function to get city coordinates if not in predefined list
def get_city_coords(city_name):
    url = f"http://api.openweathermap.org/geo/1.0/direct?q={city_name}&limit=1&appid={API_KEY}"
    response = requests.get(url)
    if response.status_code == 200 and response.json():
        data = response.json()[0]
        return data["lat"], data["lon"]
    else:
        raise Exception(f"Could not find coordinates for {city_name}")

# 1. Display Real-Time Weather Information
def get_current_weather(city):
    if city in city_coords:
        lat, lon = city_coords[city]
    else:
        lat, lon = get_city_coords(city)
        city_coords[city] = (lat, lon)

    params = {
        "lat": lat,
        "lon": lon,
        "appid": "e941583daf870839c5228a3f4a5f0ae4",
        "units": "metric"
    }
    response = requests.get(CURRENT_WEATHER_ENDPOINT, params=params)
    if response.status_code != 200:
        raise Exception(f"Error fetching current weather data for {city}: {response.text}")
    data = response.json()
    return {
        "City": city,
        "Temperature (°C)": data["main"]["temp"],
        "Humidity (%)": data["main"]["humidity"],
        "Weather": data["weather"][0]["description"]
    }

# 2. Provide 7-Day or Hourly Weather Forecasts
def get_7_day_forecast(lat, lon):
    params = {
        "lat": lat,
        "lon": lon,
        "exclude": "current,minutely,hourly,alerts",
        "appid": API_KEY,
        "units": "metric"
    }
    response = requests.get(ONE_CALL_ENDPOINT, params=params)
    if response.status_code != 200:
        raise Exception("7-day forecast data not available.")

    data = response.json()
    forecast = []
    for day in data["daily"]:
        forecast.append({
            "Date": pd.to_datetime(day["dt"], unit="s").date(),
            "Day Temp (°C)": day["temp"]["day"],
            "Humidity (%)": day["humidity"],
            "Weather": day["weather"][0]["description"]
        })
    return pd.DataFrame(forecast)

#  5. Compare Weather Between Multiple Cities or Regions
def compare_cities_weather(cities):
    weather_data = []
    for city in cities:
        try:
            data = get_current_weather(city)
            weather_data.append(data)
        except Exception as e:
            print(e)
            continue
    return pd.DataFrame(weather_data)

# 3. Analyze Historical Weather Data
def simulate_historical_weather_analysis():
    np.random.seed(0)
    days = np.arange(1, 31)
    temperatures = 30 + 5 * np.sin(0.2 * days) + np.random.normal(scale=2, size=30)

    df = pd.DataFrame({"Day": days, "Temperature": temperatures})
    X = df[["Day"]]
    y = df["Temperature"]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    model = LinearRegression()
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    return df, X_test, predictions

# 4. Alert Users of Severe Weather Conditions
def check_weather_alerts(lat, lon):
    params = {
        "lat": lat,
        "lon": lon,
        "exclude": "minutely,hourly,daily",
        "appid": API_KEY,
        "units": "metric"
    }
    response = requests.get(ONE_CALL_ENDPOINT, params=params)
    data = response.json()
    alerts = data.get("alerts", [])
    return [alert.get("event", "Unknown Alert") for alert in alerts]

# --- Enhanced Visualizations ---

def plot_realtime_weather_comparison(df):
    fig, ax1 = plt.subplots(figsize=(12, 6))
    sns.barplot(data=df, x="City", y="Temperature (°C)", ax=ax1, color="skyblue", label="Temperature")

    ax2 = ax1.twinx()
    sns.lineplot(data=df, x="City", y="Humidity (%)", ax=ax2, color="red", label="Humidity", marker='o')

    plt.title("Real-Time Weather: Temperature vs Humidity")
    ax1.set_ylabel("Temperature (°C)", color='blue')
    ax2.set_ylabel("Humidity (%)", color='red')

    fig.legend(loc="upper right", bbox_to_anchor=(0.85, 0.85))
    plt.tight_layout()
    plt.show()

    # Additional visualization: Pie chart for weather descriptions
    plt.figure(figsize=(8, 6))
    df["Weather"].value_counts().plot.pie(autopct='%1.1f%%', startangle=90, cmap="viridis")
    plt.title("Weather Description Distribution")
    plt.ylabel("")
    plt.tight_layout()
    plt.show()



def plot_historical_temperature(df, X_test, predictions):
    plt.figure(figsize=(12, 6))
    sns.lineplot(data=df, x="Day", y="Temperature", label='Actual Temperature', color='steelblue')
    sns.scatterplot(x=X_test["Day"], y=predictions, color='red', label="Predicted Temperature", s=60)

    plt.title("Simulated Historical Weather Trend & Predictions")
    plt.xlabel("Day")
    plt.ylabel("Temperature (°C)")
    plt.legend()
    plt.tight_layout()
    plt.show()

    # Additional: Regression residuals
    plt.figure(figsize=(10, 5))
    residuals = df.set_index("Day").loc[X_test["Day"]]["Temperature"] - predictions
    sns.barplot(x=X_test["Day"], y=residuals)
    plt.title("Prediction Residuals (Actual - Predicted)")
    plt.xlabel("Day")
    plt.ylabel("Residual")
    plt.tight_layout()
    plt.show()

def show_weather_alerts(alerts):
    if not alerts:
        print("✅ No alerts today.")
    else:
        print("⚠️ Active Weather Alerts:")
        for alert in alerts:
            print("🔔", alert)






# --- MAIN ---
if __name__ == "__main__":
    root = tk.Tk()
    root.withdraw()
    city_input = simpledialog.askstring("City Search", "Enter a city name to get weather forecast and graphs:")

    if city_input:
        city_input = city_input.title()
        try:
            print("\n🔵 Real-time Weather Comparison")
            cities = ["Delhi", "Mumbai", "Chennai", city_input]
            df_compare = compare_cities_weather(cities)
            if not df_compare.empty:
                print(df_compare)
                plot_realtime_weather_comparison(df_compare)
            else:
                print("No valid weather data to display.")
                exit()

            if city_input in city_coords:
                lat, lon = city_coords[city_input]
            else:
                lat, lon = get_city_coords(city_input)
                city_coords[city_input] = (lat, lon)


            print("\n📈 Historical Weather Analysis:")
            df, X_test, predictions = simulate_historical_weather_analysis()
            print(df.head())
            plot_historical_temperature(df, X_test, predictions)

            print("\n🚨 Weather Alerts:")
            alerts = check_weather_alerts(lat, lon)
            show_weather_alerts(alerts)

        except Exception as e:
            print("⚠️ An error occurred:", e)
    else:
        print("No city entered.")